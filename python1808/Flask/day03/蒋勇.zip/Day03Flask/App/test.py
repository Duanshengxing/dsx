list1 = [1,2,3]
list1.append(4)
print(list1)