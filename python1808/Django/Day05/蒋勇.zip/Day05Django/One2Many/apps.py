from django.apps import AppConfig


class One2ManyConfig(AppConfig):
    name = 'One2Many'
