from django.apps import AppConfig


class Many2ManyConfig(AppConfig):
    name = 'Many2Many'
