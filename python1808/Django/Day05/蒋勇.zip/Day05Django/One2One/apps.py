from django.apps import AppConfig


class One2OneConfig(AppConfig):
    name = 'One2One'
