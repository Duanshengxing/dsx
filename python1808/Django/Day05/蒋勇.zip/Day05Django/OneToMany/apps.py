from django.apps import AppConfig


class OnetomanyConfig(AppConfig):
    name = 'OneToMany'
