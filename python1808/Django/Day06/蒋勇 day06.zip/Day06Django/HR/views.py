from django.http import *
from django.shortcuts import *

# Create your views here.

def index(request):

    # return HttpResponseRedirect("http://www.baidu.com")
    # return JsonResponse({'username':'root'})
    # return HttpResponseNotFound("Not Found")


    print(request.path)
    print(request.method)
    print(request.GET)

    print(request.COOKIES)

    print(request.session)

    print(request.is_ajax())

    print(request.get_host())

    print(request.get_full_path())

    # print(request.META["REMOVE_ADDR"])




    response = HttpResponse("hello")
    response.content = "你好"
    response.write("山竹")
    response.flush()
    response.status_code = 404
    response.charset = 'utf-8'

    return response