from django.conf.urls import *
from .views import *


urlpatterns = [
    url('^index',index,name='index'),
]