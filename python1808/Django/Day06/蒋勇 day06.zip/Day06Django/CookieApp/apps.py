from django.apps import AppConfig


class CookieappConfig(AppConfig):
    name = 'CookieApp'
