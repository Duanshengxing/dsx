from django.shortcuts import *
from .models import *
# Create your views here.

def index(request):
    user = request.session.get('user')
    return render(request,'Cookie/index.html',{'user':user})

def login(request):

    return render(request,'Cookie/login.html')

def success(request):
    if request.method == "POST":
        user = request.POST.get("user")
        pwd = request.POST.get('pwd')
        flag = UserModel.objects.filter(user=user,pwd=pwd)
        response = HttpResponse('密码出错,或者用户不存在,登录失败！')
        if flag.exists():
            request.session['user'] = user
            return render(request,'Cookie/success.html')
        else:
            return response

    else:
        return HttpResponse('request method error')

def register(request):
    return  render(request,'Cookie/register.html')

def check(request):
    if request.method == "POST":
        user = request.POST.get("user")
        pwd = request.POST.get('pwd')
        repwd = request.POST.get('repwd')



        flag = UserModel.objects.filter(user=user,pwd=pwd)
        if flag.exists():
            return HttpResponse('用户名已存在！')
        elif pwd != repwd:
            return HttpResponse('密码两次不正确！')
        else:
            UserModel.objects.create(user=user,pwd=pwd)
            return render(request,'Cookie/login.html')


    else:
        return HttpResponse('request method error')


def cancel(request):
    response = HttpResponseRedirect(reverse('Cookie:index'))
    del  request.session['user']
    request.session.flush()
    return response